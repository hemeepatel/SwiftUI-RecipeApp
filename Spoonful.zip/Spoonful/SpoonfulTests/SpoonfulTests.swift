//
//  SpoonfulTests.swift
//  SpoonfulTests
//
//  Created by Hemee Patel on 4/15/25.
//

import Testing
@testable import Spoonful

struct SpoonfulTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
