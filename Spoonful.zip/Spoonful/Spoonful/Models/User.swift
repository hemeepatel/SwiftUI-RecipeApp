//
//  User.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

struct User: Codable {
    let username: String
    let password: String
}
