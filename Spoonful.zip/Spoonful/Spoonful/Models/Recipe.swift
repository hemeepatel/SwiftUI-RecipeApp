//
//  Recipe.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

struct Recipe: Identifiable {
    let id = UUID()
    let title: String
    let imageUrl: String
    let sourceUrl: String
}
