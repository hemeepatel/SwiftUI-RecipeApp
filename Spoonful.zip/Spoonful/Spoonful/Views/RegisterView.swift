//
//  RegisterView.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import SwiftUI

struct RegisterView: View {
    @ObservedObject var authVM: AuthViewModel
    @Environment(\.dismiss) var dismiss
    @State private var username = ""
    @State private var password = ""
    @State private var showError = false

    var body: some View {
        VStack(spacing: 20) {
            TextField("Username", text: $username)
                .textFieldStyle(.roundedBorder)

            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)

            Button("Register") {
                if authVM.register(username: username, password: password) {
                    dismiss()
                } else {
                    showError = true
                }
            }
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)

            if showError {
                Text("User already exists").foregroundColor(.red)
            }
        }
        .padding()
    }
}
