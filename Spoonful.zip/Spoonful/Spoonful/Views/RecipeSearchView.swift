//
//  RecipeSearchView.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import SwiftUI

struct RecipeSearchView: View {
    @StateObject private var viewModel = RecipeSearchViewModel()

    @State private var ingredients = ""
    @State private var diet = ""
    @State private var maxTime = ""
    @State private var maxCalories = ""

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                TextField("Ingredients (comma separated)", text: $ingredients)
                    .textFieldStyle(.roundedBorder)

                TextField("Diet (e.g. vegan, high-protein)", text: $diet)
                    .textFieldStyle(.roundedBorder)

                TextField("Max Time (mins)", text: $maxTime)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)

                TextField("Max Calories", text: $maxCalories)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)

                Button("Search Recipes") {
                    let ingredientList = ingredients.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }
                    viewModel.fetchRecipes(ingredients: ingredientList, diet: diet, maxReadyTime: Int(maxTime), maxCalories: Int(maxCalories))
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)

                if viewModel.isLoading {
                    ProgressView()
                } else {
                    List(viewModel.recipes) { recipe in
                        VStack(alignment: .leading) {
                            Text(recipe.title).font(.headline)
                            AsyncImage(url: URL(string: recipe.imageUrl)) { image in
                                image.resizable()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(height: 150)
                            .cornerRadius(8)

                            Link("View Recipe", destination: URL(string: recipe.sourceUrl)!)
                                .foregroundColor(.blue)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .padding()
            .navigationTitle("Find Recipes")
        }
    }
}
