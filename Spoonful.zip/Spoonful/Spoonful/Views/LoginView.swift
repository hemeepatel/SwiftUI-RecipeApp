//
//  LoginView.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import SwiftUI

struct LoginView: View {
    @StateObject private var authVM = AuthViewModel()
    @State private var username = ""
    @State private var password = ""
    @State private var showingRegister = false
    @State private var showError = false

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                TextField("Username", text: $username)
                    .textFieldStyle(.roundedBorder)

                SecureField("Password", text: $password)
                    .textFieldStyle(.roundedBorder)

                Button("Login") {
                    if !authVM.login(username: username, password: password) {
                        showError = true
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)

                Button("Create Account") {
                    showingRegister = true
                }
                .sheet(isPresented: $showingRegister) {
                    RegisterView(authVM: authVM)
                }

                if showError {
                    Text("Invalid login").foregroundColor(.red)
                }
            }
            .padding()
            .navigationTitle("Login")
        }
        .fullScreenCover(isPresented: $authVM.isLoggedIn) {
            RecipeSearchView()
        }
    }
}
