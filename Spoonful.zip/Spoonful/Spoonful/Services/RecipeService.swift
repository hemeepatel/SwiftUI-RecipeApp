//
//  RecipeService.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

class RecipeService {
    private let spoonacularKey = "69e60512a0a14be8a282d46cdfc37b9"

    func fetchRecipes(ingredients: [String], diet: String, maxReadyTime: Int?, maxCalories: Int?, completion: @escaping ([Recipe]) -> Void) {
        var queryItems = [
            URLQueryItem(name: "apiKey", value: spoonacularKey),
            URLQueryItem(name: "number", value: "5"),
            URLQueryItem(name: "tags", value: diet)
        ]

        if !ingredients.isEmpty {
            queryItems.append(URLQueryItem(name: "includeIngredients", value: ingredients.joined(separator: ",")))
        }

        if let maxReadyTime = maxReadyTime {
            queryItems.append(URLQueryItem(name: "maxReadyTime", value: "\(maxReadyTime)"))
        }

        if let maxCalories = maxCalories {
            queryItems.append(URLQueryItem(name: "maxCalories", value: "\(maxCalories)"))
        }

        var urlComponents = URLComponents(string: "https://api.spoonacular.com/recipes/complexSearch")!
        urlComponents.queryItems = queryItems

        guard let url = urlComponents.url else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let decoded = try? JSONDecoder().decode(SpoonacularSearchResponse.self, from: data) else {
                DispatchQueue.main.async {
                    completion([])
                }
                return
            }

            let recipes = decoded.results.map {
                Recipe(title: $0.title, imageUrl: $0.image, sourceUrl: "https://spoonacular.com/recipes/\($0.title.replacingOccurrences(of: " ", with: "-"))-\($0.id)")
            }

            DispatchQueue.main.async {
                completion(recipes.shuffled())
            }
        }.resume()
    }
}

struct SpoonacularSearchResponse: Codable {
    let results: [SpoonacularRecipe]
}

struct SpoonacularRecipe: Codable {
    let id: Int
    let title: String
    let image: String
}
