//
//  AuthService.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

class AuthService {
    static let shared = AuthService()

    private let usersKey = "users"
    private let currentUserKey = "currentUser"

    func register(user: User) -> Bool {
        var users = fetchUsers()
        if users.contains(where: { $0.username == user.username }) {
            return false
        }
        users.append(user)
        saveUsers(users)
        return true
    }

    func login(username: String, password: String) -> Bool {
        let users = fetchUsers()
        if let user = users.first(where: { $0.username == username && $0.password == password }) {
            saveCurrentUser(user)
            return true
        }
        return false
    }

    func logout() {
        UserDefaults.standard.removeObject(forKey: currentUserKey)
    }

    func isLoggedIn() -> Bool {
        return UserDefaults.standard.object(forKey: currentUserKey) != nil
    }

    private func fetchUsers() -> [User] {
        if let data = UserDefaults.standard.data(forKey: usersKey),
           let users = try? JSONDecoder().decode([User].self, from: data) {
            return users
        }
        return []
    }

    private func saveUsers(_ users: [User]) {
        if let data = try? JSONEncoder().encode(users) {
            UserDefaults.standard.set(data, forKey: usersKey)
        }
    }

    private func saveCurrentUser(_ user: User) {
        if let data = try? JSONEncoder().encode(user) {
            UserDefaults.standard.set(data, forKey: currentUserKey)
        }
    }
}
