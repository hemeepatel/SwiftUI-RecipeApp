//
//  RecipeSearchViewModel.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

class RecipeSearchViewModel: ObservableObject {
    @Published var recipes: [Recipe] = []
    @Published var isLoading = false

    private let service = RecipeService()

    func fetchRecipes(ingredients: [String], diet: String, maxReadyTime: Int?, maxCalories: Int?) {
        isLoading = true
        service.fetchRecipes(ingredients: ingredients, diet: diet, maxReadyTime: maxReadyTime, maxCalories: maxCalories) { [weak self] result in
            DispatchQueue.main.async {
                self?.recipes = result
                self?.isLoading = false
            }
        }
    }
}
