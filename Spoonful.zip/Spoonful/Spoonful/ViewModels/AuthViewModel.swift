//
//  AuthViewModel.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import Foundation

class AuthViewModel: ObservableObject {
    @Published var isLoggedIn = AuthService.shared.isLoggedIn()

    func register(username: String, password: String) -> Bool {
        let user = User(username: username, password: password)
        let success = AuthService.shared.register(user: user)
        if success { isLoggedIn = true }
        return success
    }

    func login(username: String, password: String) -> Bool {
        let success = AuthService.shared.login(username: username, password: password)
        if success { isLoggedIn = true }
        return success
    }

    func logout() {
        AuthService.shared.logout()
        isLoggedIn = false
    }
}
