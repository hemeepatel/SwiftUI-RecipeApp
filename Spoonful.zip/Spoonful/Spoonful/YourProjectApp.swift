//
//  YourProjectApp.swift
//  Spoonful
//
//  Created by Hemee Patel on 4/15/25.
//


import SwiftUI

@main
struct YourProjectApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()  
        }
    }
}
